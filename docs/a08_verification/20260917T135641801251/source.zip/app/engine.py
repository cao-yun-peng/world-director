"""单进程、顺序执行的提交点：世界与回合记录一起替换。"""

import asyncio
import hashlib
import json
from copy import deepcopy
from dataclasses import asdict

from app.actions import ActionProposal, normalize_action
from app.world import WorldState, adjudicate, append_statement, result


class TurnConflict(ValueError):
    pass


def request_digest(entry: str, value) -> str:
    wire = json.dumps({"entry": entry, "request": value}, sort_keys=True,
                      separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    return hashlib.sha256(wire.encode("utf-8")).hexdigest()


class WorldEngine:
    def __init__(self, world: WorldState):
        self._bundle = {"world": deepcopy(world), "turns": {}, "scene_receipts": {}}
        self.turn_lock = asyncio.Lock()

    @property
    def world(self) -> WorldState:
        return deepcopy(self._bundle["world"])

    @property
    def turns(self) -> dict:
        return deepcopy(self._bundle["turns"])

    @property
    def story_ended(self) -> bool:
        return any(event['kind'] == 'EndingEvent' for event in self._bundle['world'].events)

    def submit_scene(self, operation, payload, *, request_id, scene_turn_id,
                     expected_revision=None, before_accept=None):
        """场景状态与事件一起接纳；不接受模型提供的任意状态补丁。"""
        from app.director import adjudicate_scene
        if not isinstance(request_id, str) or not request_id.strip() or not isinstance(scene_turn_id, str) or not scene_turn_id.strip():
            raise ValueError('场景请求 ID 必须非空。')
        digest = request_digest('scene_operation', {'operation': operation, 'payload': payload,
                                                   'scene_turn_id': scene_turn_id,
                                                   'expected_revision': expected_revision})
        key = (self._bundle['world'].session_id, request_id)
        previous = self._bundle['scene_receipts'].get(key)
        if previous:
            if previous['request_digest'] != digest:
                raise TurnConflict('同一场景子请求 ID 已用于不同参数。')
            return deepcopy(previous)
        world = self.world
        if expected_revision is not None and expected_revision != world.revision:
            candidate, receipt, events = world, result(False, 'STALE_REVISION', '场景版本已变化。'), []
        else:
            candidate, receipt, events = adjudicate_scene(world, operation, payload, scene_turn_id=scene_turn_id)
        record = {'request_digest': digest, 'receipt': receipt, 'event_ids': [e['event_id'] for e in events],
                  'before_revision': world.revision, 'after_revision': candidate.revision}
        receipts = deepcopy(self._bundle['scene_receipts'])
        receipts[key] = record
        if before_accept is not None:
            before_accept()
        self._bundle = {**self._bundle, 'world': candidate, 'scene_receipts': receipts}
        return deepcopy(record)

    def lookup(self, *, actor_id: str, turn_id: str, digest: str) -> dict | None:
        world = self._bundle["world"]
        if actor_id not in world.actor_locations:
            raise ValueError("未登记的可信行动者。")
        if not isinstance(turn_id, str) or not turn_id.strip():
            raise ValueError("turn_id 必须非空。")
        key = (world.session_id, actor_id, turn_id)
        previous = self._bundle["turns"].get(key)
        if previous and previous["request_digest"] != digest:
            raise TurnConflict("同一 turn_id 已用于不同请求。")
        return deepcopy(previous)

    def submit_action(self, proposal: ActionProposal, *, actor_id: str, turn_id: str,
                      cause_event_id: str | None = None) -> dict:
        proposal = normalize_action(proposal)
        digest = request_digest("action", {"proposal": asdict(proposal), "cause_event_id": cause_event_id})
        previous = self.lookup(actor_id=actor_id, turn_id=turn_id, digest=digest)
        if previous is not None:
            return previous
        return self.commit_turn(proposal, [proposal], actor_id=actor_id, turn_id=turn_id,
                                digest=digest, cause_event_id=cause_event_id)

    def commit_turn(self, proposal: ActionProposal, operations: list[ActionProposal], *,
                    actor_id: str, turn_id: str, digest: str,
                    cause_event_id: str | None = None, feedback: list[dict] | None = None,
                    before_accept=None, expected_revision: int | None = None,
                    player_text: str | None = None, record_reply: bool = False) -> dict:
        """operations/feedback 来自可信运行时，绝不直接消费模型提供的成功标志。"""
        previous = self.lookup(actor_id=actor_id, turn_id=turn_id, digest=digest)
        if previous is not None:
            return previous
        if self.story_ended:
            return {"request_digest": digest, "proposal": asdict(proposal),
                    "receipt": result(False, 'STORY_ENDED', '本章已结束。'),
                    "results": [], "event_ids": [], "before_revision": self.world.revision,
                    "after_revision": self.world.revision, "reply": '本章已结束。',
                    "narration_status": 'deterministic', "session": None, "trace": None}
        if expected_revision is not None and self._bundle["world"].revision != expected_revision:
            raise TurnConflict("查询快照已过期。")
        candidate = self.world
        receipts, events = [], []
        if player_text is not None:
            candidate, incoming, emitted = append_statement(
                candidate, speaker_id="player", recipient_id=actor_id, text=player_text,
                turn_id=turn_id, channel="player_dialogue")
            if not incoming["ok"]:
                raise ValueError("玩家消息无效。")
            events.extend(emitted)
        for operation in operations:
            candidate, receipt, emitted = adjudicate(
                candidate, operation, actor_id=actor_id, turn_id=turn_id, cause_event_id=cause_event_id)
            receipts.append(receipt)
            events.extend(emitted)
            if not receipt["ok"]:
                break
        if feedback is None:
            receipt = receipts[-1]
        else:
            messages = []
            for item in feedback:
                if not item["ok"]:
                    messages.append(item["error"]["message"])
                elif "description" in item["data"]:
                    messages.append(item["data"]["description"])
                else:
                    scene = item["data"]
                    names = "、".join(obj["name"] for obj in scene["objects"]) or "暂无可见物品"
                    messages.append(f"当前位置 {scene['location_id']}；可见：{names}。")
            ok = all(item["ok"] for item in feedback) and all(item["ok"] for item in receipts)
            receipt = result(ok, "OBSERVED" if ok else "OBSERVATION_ERRORS", "\n".join(messages))
        if not receipt["ok"]:
            # 包括先发现、后行动被拒绝：不留下半份世界更新。
            candidate, events = self.world, []
        if receipt["ok"] and (player_text is not None or record_reply) and proposal.kind in ("talk", "clarify", "wait"):
            candidate, _, emitted = append_statement(
                candidate, speaker_id=actor_id, recipient_id="player", text=proposal.reply,
                turn_id=turn_id, channel="player_dialogue")
            events.extend(emitted)
        record = {
            "request_digest": digest, "proposal": asdict(proposal),
            "receipt": receipt, "results": receipts, "event_ids": [e["event_id"] for e in events],
            "before_revision": self._bundle["world"].revision, "after_revision": candidate.revision,
            "reply": receipt["message"], "narration_status": "deterministic",
            "session": None, "trace": None,
        }
        turns = deepcopy(self._bundle["turns"])
        turns[(candidate.session_id, actor_id, turn_id)] = deepcopy(record)
        if before_accept is not None:
            before_accept()
        # 本日仅顺序调用。这是完整候选包的单次接纳，不是并发/持久化事务。
        self._bundle = {**self._bundle, "world": candidate, "turns": turns}
        return deepcopy(record)

    def finish_turn(self, *, actor_id: str, turn_id: str, session: dict, reply: str, trace: dict, status: str) -> None:
        """只补回执与历史，不再改动已结算的世界。"""
        candidate = deepcopy(self._bundle)
        record = candidate["turns"][(candidate["world"].session_id, actor_id, turn_id)]
        record.update(session=deepcopy(session), reply=reply, trace=deepcopy(trace),
                      narration_status=status)
        self._bundle = candidate
